<?php

use PHPUnit\Framework\TestCase;
use app\User;


class UserTest extends TestCase
{

    public function testConstruct()
    {
        $user = new User(1, "Mars");
        $this->assertSame(1, $user->id);
        $this->assertSame("Mars", $user->name);
    }

}
?>