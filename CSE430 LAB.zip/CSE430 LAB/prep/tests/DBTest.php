<?php

use PHPUnit\Framework\TestCase;

class DBTest extends TestCase
{

    protected $db;

    protected function setUp(): void
    {
        $this->db = new PDO('mysql:host=localhost;dbname=testdb', 'root', '');
    }

    public function testInsert()
    {
        $query = "INSERT INTO users (id,name) VALUES (1,'Mars')";
        $result = $this->db->exec($query);
        $this->assertNotFalse($result, "Insertion Failed");
    }

    public function testSelect()
    {

        $query = "SELECT * FROM users";
        $result = $this->db->query($query);
        $this->assertNotFalse($result, "Selection Failed");
        $data = $result->fetchAll(PDO::FETCH_ASSOC);
        var_dump($data);

    }

    public function testUpdate()
    {

        $query = "UPDATE users SET name = 'MarSisFaster' where id = 1";
        $result = $this->db->exec($query);
        $this->assertNotFalse($result, "Updation Failed");
    }

    public function testCount()
    {

        $query = "SELECT COUNT(*) from users";
        $result = $this->db->query($query);
        $this->assertNotFalse($result, "Count Operation Failed");
        $count = $result->fetchColumn();
        echo ($count);
    }

    public function testDelete()
    {

        $query = "DELETE FROM users Where id = 1";
        $result = $this->db->exec($query);
        $this->assertNotFalse($result, "Deletion Failed");
    }

    protected function tearDown(): void
    {
        $this->db = null;
    }
}
?>