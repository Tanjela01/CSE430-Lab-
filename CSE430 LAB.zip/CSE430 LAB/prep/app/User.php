<?php

namespace app;

class User
{

    public int $id;
    public string $name;

    public function __construct(int $id, string $name)
    {

        $this->id = $id;
        $this->name = $name;

    }

    public function id()
    {
        return $this->id;
    }

    public function getName()
    {
        return $this->name;
    }
}
?>