<?php

use app\user;
use PHPUnit\Framework\TestCase;

class userTest extends TestCase{
    public function testconstruct():void{
        $user =new user('1','tanjela');
        $this->assertSame(1,$user->id);
        $this->assertSame("tanjela",$user->name);
    }
}
?>